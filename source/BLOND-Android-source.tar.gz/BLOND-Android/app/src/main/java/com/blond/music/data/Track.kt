package com.blond.music.data

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val artworkUrl: String?,
    val durationSeconds: Int,
    val playCount: Long,
    val streamUrl: String,
    val permalink: String?
) {
    val durationLabel: String
        get() = "%d:%02d".format(durationSeconds / 60, durationSeconds % 60)
}
