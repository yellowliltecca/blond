package com.blond.music

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.blond.music.data.AudiusApi
import com.blond.music.data.Track
import com.blond.music.player.PlaybackService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Blue = Color(0xFF2563EB)
private val Ink = Color(0xFF111827)
private val Muted = Color(0xFF7B8494)
private val Canvas = Color(0xFFF6F8FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BlondApp() }
    }
}

private enum class Tab(val label: String) {
    HOME("Главная"), SEARCH("Поиск"), LIBRARY("Моя музыка"), PROFILE("Профиль")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlondApp() {
    val context = LocalContext.current
    val api = remember { AudiusApi() }
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("blond_local", Context.MODE_PRIVATE) }
    val favorites = remember { mutableStateListOf<Track>() }
    val history = remember { mutableStateListOf<Track>() }
    var allTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var searchResults by remember { mutableStateOf<List<Track>>(emptyList()) }
    var searchText by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(Tab.HOME) }
    var isLoading by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var playbackProgress by remember { mutableIntStateOf(0) }
    var playbackQueue by remember { mutableStateOf<List<Track>>(emptyList()) }

    val sessionToken = remember { SessionToken(context, ComponentName(context, PlaybackService::class.java)) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    val controllerFuture = remember(sessionToken) { MediaController.Builder(context, sessionToken).buildAsync() }

    DisposableEffect(controllerFuture) {
        controllerFuture.addListener({
            controller = runCatching { controllerFuture.get() }.getOrNull()
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            MediaController.releaseFuture(controllerFuture)
            controller = null
        }
    }

    DisposableEffect(controller) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                playbackProgress++
                playbackQueue.firstOrNull { it.id == mediaItem?.mediaId }?.let { currentTrack = it }
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                playbackProgress++
            }
        }
        controller?.addListener(listener)
        onDispose { controller?.removeListener(listener) }
    }

    fun loadHome() {
        scope.launch {
            isLoading = true
            errorText = null
            try {
                allTracks = api.trending()
                if (allTracks.isEmpty()) errorText = "Пока не удалось получить популярные треки. Попробуй обновить каталог."
            } catch (e: Exception) {
                errorText = e.message ?: "Не удалось загрузить каталог"
            } finally {
                isLoading = false
            }
        }
    }

    fun toggleFavorite(track: Track) {
        val exists = favorites.any { it.id == track.id }
        if (exists) favorites.removeAll { it.id == track.id } else favorites.add(0, track)
        prefs.edit().putStringSet("favorite_ids", favorites.map { it.id }.toSet()).apply()
        // Keep full track details locally so the library is available on the next launch.
        prefs.edit().putString("favorite_tracks", favorites.joinToString("\n") { listOf(it.id, it.title, it.artist, it.artworkUrl.orEmpty(), it.durationSeconds, it.playCount, it.permalink.orEmpty()).joinToString("\t") }).apply()
    }

    fun playTrack(track: Track) {
        val mediaController = controller ?: run {
            errorText = "Плеер подключается. Попробуй ещё раз через секунду."
            return
        }
        val sourceQueue = when (selectedTab) {
            Tab.HOME -> allTracks
            Tab.SEARCH -> searchResults
            Tab.LIBRARY -> if (favorites.any { it.id == track.id }) favorites.toList() else history.toList()
            Tab.PROFILE -> listOf(track)
        }.ifEmpty { listOf(track) }
        playbackQueue = sourceQueue
        val startIndex = sourceQueue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        val items = sourceQueue.map { itemTrack ->
            val metadata = MediaMetadata.Builder()
                .setTitle(itemTrack.title)
                .setArtist(itemTrack.artist)
                .setArtworkUri(itemTrack.artworkUrl?.let { android.net.Uri.parse(it) })
                .build()
            MediaItem.Builder()
                .setMediaId(itemTrack.id)
                .setUri(itemTrack.streamUrl)
                .setMediaMetadata(metadata)
                .build()
        }
        mediaController.setMediaItems(items, startIndex, 0L)
        mediaController.prepare()
        mediaController.play()
        currentTrack = track
        showPlayer = true
        history.removeAll { it.id == track.id }
        history.add(0, track)
        if (history.size > 20) history.removeAt(history.lastIndex)
    }

    LaunchedEffect(Unit) {
        val stored = prefs.getString("favorite_tracks", "").orEmpty()
        stored.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val parts = line.split('\t')
            if (parts.size >= 7) {
                val id = parts[0]
                val duration = parts[4].toIntOrNull() ?: 0
                val plays = parts[5].toLongOrNull() ?: 0L
                favorites.add(Track(id, parts[1], parts[2], parts[3].ifBlank { null }, duration, plays, "https://api.audius.co/v1/tracks/$id/stream", parts[6].ifBlank { null }))
            }
        }
        loadHome()
    }

    LaunchedEffect(selectedTab, searchText) {
        if (selectedTab == Tab.SEARCH && searchText.trim().length >= 2) {
            delay(350)
            isLoading = true
            errorText = null
            try {
                searchResults = api.search(searchText)
            } catch (e: Exception) {
                searchResults = emptyList()
                errorText = e.message ?: "Ошибка поиска"
            } finally {
                isLoading = false
            }
        } else if (selectedTab == Tab.SEARCH && searchText.isBlank()) {
            searchResults = emptyList()
        }
    }

    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(
            primary = Blue,
            onPrimary = Color.White,
            background = Canvas,
            surface = Color.White,
            onSurface = Ink,
            onBackground = Ink,
            secondary = Color(0xFF5B8DEF)
        )
    ) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                Column {
                    AnimatedVisibility(currentTrack != null) {
                        currentTrack?.let { track ->
                            MiniPlayer(
                                track = track,
                                playing = playing,
                                onOpen = { showPlayer = true },
                                onPlayPause = {
                                    if (controller?.isPlaying == true) controller?.pause() else controller?.play()
                                }
                            )
                        }
                    }
                    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                        listOf(
                            Tab.HOME to Icons.Default.Home,
                            Tab.SEARCH to Icons.Default.Search,
                            Tab.LIBRARY to Icons.Default.LibraryMusic,
                            Tab.PROFILE to Icons.Default.PersonOutline
                        ).forEach { (tab, icon) ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = { Icon(icon, contentDescription = tab.label) },
                                label = { Text(tab.label, fontSize = 10.sp, maxLines = 1) },
                                alwaysShowLabel = true
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selectedTab) {
                    Tab.HOME -> HomeScreen(
                        tracks = allTracks,
                        isLoading = isLoading,
                        errorText = errorText,
                        onSearch = { selectedTab = Tab.SEARCH },
                        onPlay = ::playTrack,
                        onFavorite = ::toggleFavorite,
                        isFavorite = { track -> favorites.any { it.id == track.id } },
                        onRefresh = ::loadHome
                    )
                    Tab.SEARCH -> SearchScreen(
                        query = searchText,
                        onQueryChange = { searchText = it },
                        tracks = searchResults,
                        isLoading = isLoading,
                        errorText = errorText,
                        onPlay = ::playTrack,
                        onFavorite = ::toggleFavorite,
                        isFavorite = { track -> favorites.any { it.id == track.id } }
                    )
                    Tab.LIBRARY -> LibraryScreen(
                        favorites = favorites,
                        history = history,
                        onPlay = ::playTrack,
                        onFavorite = ::toggleFavorite
                    )
                    Tab.PROFILE -> ProfileScreen()
                }
            }
        }

        if (showPlayer && currentTrack != null) {
            ModalBottomSheet(
                onDismissRequest = { showPlayer = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = Color.White
            ) {
                FullPlayer(
                    track = currentTrack!!,
                    playing = playing,
                    controller = controller,
                    onClose = { showPlayer = false },
                    onToggle = { if (controller?.isPlaying == true) controller?.pause() else controller?.play() },
                    progressKey = playbackProgress
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    tracks: List<Track>, isLoading: Boolean, errorText: String?, onSearch: () -> Unit,
    onPlay: (Track) -> Unit, onFavorite: (Track) -> Unit,
    isFavorite: (Track) -> Boolean, onRefresh: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("BLOND", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Blue, letterSpacing = 1.5.sp)
                    Text("Музыка, которая совпадает с тобой", fontSize = 12.sp, color = Muted)
                }
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFEAF1FF)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = Blue, modifier = Modifier.size(22.dp))
                }
            }
        }
        item {
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { onSearch() },
                shape = RoundedCornerShape(18.dp), color = Color.White, shadowElevation = 1.dp
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = Muted)
                    Spacer(Modifier.width(10.dp))
                    Text("Найти трек или исполнителя", color = Muted, fontSize = 14.sp)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Твоя музыка начинается здесь", fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Открывай новое и возвращайся к любимому", fontSize = 13.sp, color = Muted)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Популярное сейчас", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Треки, которые слушают на Audius", fontSize = 12.sp, color = Muted)
                }
                TextButton(onClick = onRefresh) { Text("Обновить", color = Blue) }
            }
        }
        if (isLoading && tracks.isEmpty()) {
            item { Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) } }
        }
        if (errorText != null && tracks.isEmpty()) {
            item { ErrorPanel(errorText, onRefresh) }
        }
        if (tracks.isNotEmpty()) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(tracks.take(12), key = { it.id }) { track ->
                        TrackPoster(track = track, onClick = { onPlay(track) })
                    }
                }
            }
            item {
                Text("Топ недели", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
            items(tracks.drop(12), key = { it.id }) { track ->
                TrackRow(track, isFavorite(track), onPlay = { onPlay(track) }, onFavorite = { onFavorite(track) })
            }
        }
        item {
            Text("Музыкальный каталог предоставлен Audius. Доступность отдельных треков зависит от правообладателей и региона.", fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
private fun SearchScreen(
    query: String, onQueryChange: (String) -> Unit, tracks: List<Track>, isLoading: Boolean,
    errorText: String?, onPlay: (Track) -> Unit, onFavorite: (Track) -> Unit, isFavorite: (Track) -> Boolean
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 18.dp)) {
        Text("Поиск", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            placeholder = { Text("Трек, исполнитель или альбом") },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Blue) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { onQueryChange("") }) { Icon(Icons.Default.Close, "Очистить") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
        )
        Spacer(Modifier.height(14.dp))
        when {
            query.trim().length < 2 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Search, null, tint = Color(0xFFB5C4DC), modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Начни вводить название или имя", color = Muted, fontSize = 13.sp)
                }
            }
            isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) }
            errorText != null && tracks.isEmpty() -> ErrorPanel(errorText) {}
            tracks.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Ничего не найдено", color = Muted) }
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp)) {
                item { Text("Результаты · ${tracks.size}", color = Muted, fontSize = 12.sp) }
                items(tracks, key = { it.id }) { track ->
                    TrackRow(track, isFavorite(track), onPlay = { onPlay(track) }, onFavorite = { onFavorite(track) })
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen(favorites: List<Track>, history: List<Track>, onPlay: (Track) -> Unit, onFavorite: (Track) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Моя музыка", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(4.dp))
            Text("Всё, что хочется сохранить", fontSize = 13.sp, color = Muted)
        }
        item { Text("Избранное", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink) }
        if (favorites.isEmpty()) {
            item { EmptyPanel("Здесь будут любимые треки", "Нажимай на сердечко рядом с песней, чтобы сохранить её") }
        } else {
            items(favorites, key = { "fav-${it.id}" }) { track -> TrackRow(track, true, onPlay = { onPlay(track) }, onFavorite = { onFavorite(track) }) }
        }
        item { Spacer(Modifier.height(8.dp)); Text("Недавно слушал", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink) }
        if (history.isEmpty()) {
            item { EmptyPanel("История пока пуста", "Включи любой трек — он появится здесь") }
        } else {
            items(history, key = { "hist-${it.id}" }) { track -> TrackRow(track, favorites.any { f -> f.id == track.id }, onPlay = { onPlay(track) }, onFavorite = { onFavorite(track) }) }
        }
    }
}

@Composable
private fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Профиль", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(76.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Blue, Color(0xFF8DB5FF)))), contentAlignment = Alignment.Center) {
                    Text("B", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text("Твой BLOND", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                Text("Персональный профиль появится в следующих версиях", fontSize = 12.sp, color = Muted)
            }
        }
        Text("Версия 0.1.0 · Каталог Audius", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun TrackPoster(track: Track, onClick: () -> Unit) {
    Column(Modifier.width(142.dp).clickable { onClick() }, verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Box(Modifier.size(142.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFFE7EEF9))) {
            Artwork(track.artworkUrl, Modifier.fillMaxSize())
            Box(Modifier.align(Alignment.BottomEnd).padding(8.dp).size(34.dp).clip(CircleShape).background(Blue), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
        }
        Text(track.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(track.artist, fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TrackRow(track: Track, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 0.5.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE7EEF9)).clickable { onPlay() }) {
                Artwork(track.artworkUrl, Modifier.fillMaxSize())
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).clickable { onPlay() }, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(track.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, fontSize = 12.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.durationLabel, fontSize = 10.sp, color = Muted)
            }
            IconButton(onClick = onFavorite) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "В избранное", tint = if (favorite) Blue else Muted)
            }
            IconButton(onClick = onPlay) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Слушать", tint = Blue)
            }
        }
    }
}

@Composable
private fun Artwork(url: String?, modifier: Modifier = Modifier) {
    if (!url.isNullOrBlank()) {
        AsyncImage(model = url, contentDescription = "Обложка трека", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    } else {
        Box(modifier.background(Brush.linearGradient(listOf(Color(0xFFDCE8FF), Color(0xFFF1F5FC)))), contentAlignment = Alignment.Center) {
            Text("B", color = Blue.copy(alpha = 0.65f), fontWeight = FontWeight.Black, fontSize = 27.sp)
        }
    }
}

@Composable
private fun MiniPlayer(track: Track, playing: Boolean, onOpen: () -> Unit, onPlayPause: () -> Unit) {
    Surface(color = Color.White, shadowElevation = 10.dp, modifier = Modifier.fillMaxWidth().clickable { onOpen() }) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFE7EEF9))) { Artwork(track.artworkUrl, Modifier.fillMaxSize()) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(track.title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onPlayPause) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "Пауза" else "Продолжить", tint = Blue)
            }
        }
    }
}

@Composable
private fun FullPlayer(track: Track, playing: Boolean, controller: MediaController?, onClose: () -> Unit, onToggle: () -> Unit, progressKey: Int) {
    var sliderPosition by remember(track.id) { mutableStateOf(0f) }
    val duration = (controller?.duration?.takeIf { it > 0 } ?: track.durationSeconds * 1000L).toFloat()
    LaunchedEffect(progressKey, controller) {
        if (controller != null && controller.duration > 0) sliderPosition = controller.currentPosition.toFloat()
    }
    LaunchedEffect(controller, track.id) {
        while (true) {
            if (controller != null && controller.duration > 0) {
                sliderPosition = controller.currentPosition.toFloat()
            }
            delay(500)
        }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp).padding(bottom = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Свернуть") }
            Text("СЕЙЧАС ИГРАЕТ", fontSize = 10.sp, letterSpacing = 1.5.sp, color = Muted, fontWeight = FontWeight.Bold)
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(26.dp)).background(Color(0xFFE7EEF9)).aspectRatioCompat(1f)) {
            Artwork(track.artworkUrl, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(28.dp))
        Text(track.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(6.dp))
        Text(track.artist, fontSize = 14.sp, color = Muted)
        Spacer(Modifier.height(20.dp))
        Slider(
            value = sliderPosition.coerceIn(0f, duration.coerceAtLeast(1f)),
            onValueChange = { sliderPosition = it },
            onValueChangeFinished = { controller?.seekTo(sliderPosition.toLong()) },
            valueRange = 0f..duration.coerceAtLeast(1f),
            colors = androidx.compose.material3.SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(sliderPosition.toLong()), fontSize = 11.sp, color = Muted)
            Text(formatTime(duration.toLong()), fontSize = 11.sp, color = Muted)
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(30.dp)) {
            IconButton(onClick = { controller?.seekToPreviousMediaItem() }, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.SkipPrevious, "Предыдущий трек", tint = Ink, modifier = Modifier.size(30.dp)) }
            Box(Modifier.size(70.dp).clip(CircleShape).background(Blue).clickable { onToggle() }, contentAlignment = Alignment.Center) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Пауза" else "Играть", tint = Color.White, modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = { controller?.seekToNextMediaItem() }, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.SkipNext, "Следующий трек", tint = Ink, modifier = Modifier.size(30.dp)) }
        }
        Spacer(Modifier.height(12.dp))
        Text("Воспроизведение через Audius", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ErrorPanel(message: String, onRetry: () -> Unit) {
    Surface(shape = RoundedCornerShape(18.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Не удалось загрузить музыку", color = Ink, fontWeight = FontWeight.Bold)
            Text(message, color = Muted, fontSize = 12.sp)
            TextButton(onClick = onRetry) { Text("Повторить", color = Blue) }
        }
    }
}

@Composable
private fun EmptyPanel(title: String, subtitle: String) {
    Surface(shape = RoundedCornerShape(18.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

private fun formatTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

private fun Modifier.aspectRatioCompat(ratio: Float): Modifier = this.aspectRatio(ratio)
