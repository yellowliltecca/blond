package com.blond.music.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Read-only Audius API client. No user token is required for public catalog endpoints. */
class AudiusApi {
    private val baseUrl = "https://api.audius.co/v1"

    suspend fun trending(limit: Int = 24): List<Track> = withContext(Dispatchers.IO) {
        requestTracks("$baseUrl/tracks/trending?time=week&limit=$limit&app_name=BLOND")
    }

    suspend fun search(query: String, limit: Int = 30): List<Track> = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(query.trim(), Charsets.UTF_8.name())
        requestTracks("$baseUrl/tracks/search?query=$encoded&limit=$limit&app_name=BLOND")
    }

    private fun requestTracks(address: String): List<Track> {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 18_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "BLOND-Android/0.1")
        }

        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) {
                val message = runCatching { JSONObject(body).optString("message") }.getOrNull()
                throw IllegalStateException(message?.takeIf { it.isNotBlank() } ?: "Audius вернул ошибку HTTP $code")
            }

            val root = JSONObject(body)
            val data = root.optJSONArray("data") ?: return emptyList()
            return buildList {
                for (index in 0 until data.length()) {
                    val item = data.optJSONObject(index) ?: continue
                    val id = item.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: continue
                    val user = item.optJSONObject("user")
                    val artwork = item.optJSONObject("artwork")
                    val image = artwork?.optString("480x480")
                        ?.takeIf { !it.isNullOrBlank() && it != "null" }
                        ?: artwork?.optString("150x150")?.takeIf { !it.isNullOrBlank() && it != "null" }
                    add(
                        Track(
                            id = id,
                            title = item.optString("title", "Без названия").ifBlank { "Без названия" },
                            artist = user?.optString("name")?.takeIf { !it.isNullOrBlank() && it != "null" } ?: "Неизвестный исполнитель",
                            artworkUrl = image,
                            durationSeconds = item.optInt("duration", 0).coerceAtLeast(0),
                            playCount = item.optLong("play_count", 0L).coerceAtLeast(0L),
                            streamUrl = "$baseUrl/tracks/$id/stream",
                            permalink = item.optString("permalink").takeIf { !it.isNullOrBlank() && it != "null" }
                        )
                    )
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
