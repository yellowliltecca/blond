# BLOND — Android music app (prototype 0.1.0)

BLOND is a Kotlin + Jetpack Compose Android prototype with a light white/blue interface.

## Included in this first build

- Home screen with Audius weekly trending tracks.
- Search for public Audius tracks.
- Track artwork, artist, duration and play count data parsing.
- Favorites saved locally on the device.
- Recently played list for the current app session.
- Media3 ExoPlayer hosted in a `MediaSessionService` for background playback and Android media controls.
- Mini-player and expanded player sheet.

## Requirements

- Android Studio with JDK 17.
- Android SDK Platform 36.
- Gradle 8.13 (the wrapper distribution is configured in `gradle/wrapper/gradle-wrapper.properties`).

## Open the project

1. Extract the archive.
2. In Android Studio choose **Open** and select the `BLOND-Android` folder.
3. Allow Gradle sync and Android Studio to download dependencies.
4. Connect an Android device or start an emulator (Android 8.0 / API 26 or newer).
5. Press **Run**.

The wrapper JAR is not embedded in this source archive. On Windows, run `setup-gradle.bat` once; it downloads Gradle 8.13 and generates the wrapper files. Then open the folder in Android Studio and sync. To build a debug APK from the command line after Android SDK setup, run `build-debug.bat`.

## Audius API

The app uses the public read-only Audius API:

- `GET https://api.audius.co/v1/tracks/trending`
- `GET https://api.audius.co/v1/tracks/search`
- `GET https://api.audius.co/v1/tracks/{track_id}/stream`

Most read-only Audius endpoints are documented as usable without credentials. An API key can increase rate limits. Do not embed a private API secret in a distributed Android APK; use a backend if the production app needs protected credentials or higher-volume traffic.

API documentation: https://docs.audius.co/api/

## Important licensing note

Audius API access is not a blanket commercial music licence. Before publishing BLOND, review Audius terms and the applicable rights/licensing for each track, and obtain any required permissions for monetization, offline downloads, caching, or redistribution. This prototype does not implement downloads or offline playback.

## Current limitations

- No BLOND account system or cloud sync yet.
- Favorites are stored locally with SharedPreferences; history currently lasts only while the app process is alive. Room migration is planned for a later iteration.
- No subscription, payments, recommendations model, or commercial music catalogue integration yet.
- This source package has not been built on a local Android SDK in this environment. Perform Gradle sync/build in Android Studio and share any build error for correction.
