@echo off
setlocal
set GRADLE_VERSION=8.13
set BOOTSTRAP=%USERPROFILE%\.gradle\blond-bootstrap
set DIST=%BOOTSTRAP%\gradle-%GRADLE_VERSION%
set ZIP=%BOOTSTRAP%\gradle-%GRADLE_VERSION%-bin.zip

if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BOOTSTRAP%" mkdir "%BOOTSTRAP%"
  echo Downloading Gradle %GRADLE_VERSION% (one-time download, about 130 MB)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 1
  echo Extracting Gradle...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%BOOTSTRAP%' -Force"
  if errorlevel 1 exit /b 1
)

cd /d "%~dp0"
if not exist "local.properties" if exist "%LOCALAPPDATA%\Android\Sdk" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-Content -Path 'local.properties' -Value ('sdk.dir=' + $env:LOCALAPPDATA.Replace('\','/') + '/Android/Sdk')"
)
call "%DIST%\bin\gradle.bat" wrapper --gradle-version %GRADLE_VERSION%
if errorlevel 1 exit /b 1
echo.
echo Gradle wrapper generated successfully.
echo Next: open this folder in Android Studio and sync the project.
endlocal
