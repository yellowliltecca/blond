@echo off
setlocal
cd /d "%~dp0"
if not exist "gradlew.bat" (
  echo Gradle wrapper is missing. Run setup-gradle.bat first.
  exit /b 1
)
call gradlew.bat assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK created at: app\build\outputs\apk\debug\app-debug.apk
endlocal
