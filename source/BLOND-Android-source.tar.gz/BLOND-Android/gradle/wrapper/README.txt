The Gradle wrapper distribution is set to Gradle 8.13 in gradle-wrapper.properties.
The wrapper JAR is not bundled in this archive. If Android Studio does not regenerate it automatically, run:
  gradle wrapper --gradle-version 8.13
from the project root on a machine with Gradle installed.
